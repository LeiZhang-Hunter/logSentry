// console.log(document.getElementById("client_id"));
// alert(document.getElementById("client_id").value);
// alert(document.getElementById("server_ip").value);
// alert(document.getElementById("server_port").value)

var Extension = {

    config : {
        "client_id": "test",
        "server_ip" : "192.168.59.127",
        "server_port": "6008"
    },


    socket:"",

    //收到数据
    runRecv:function(){
        this.socket.addEventListener('message',function(event){
            console.log('Message from server ', event.data);
        });
    },

    createWebSocket:function(){
        const socket = new WebSocket('ws://'+this.config["server_ip"]+':'+this.config["server_port"]);

        socket.addEventListener('open', function (event) {
            // 发送client_id
            socket.send(Extension.config.client_id);
        });

        this.socket = socket;
    },

    run:function () {
        this.createWebSocket();
        this.runRecv();
    }
};
Extension.run();